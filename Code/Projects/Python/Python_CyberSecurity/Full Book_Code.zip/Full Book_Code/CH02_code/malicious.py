print("I am a malicious program.")
input()